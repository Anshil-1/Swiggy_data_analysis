
-- 1 Total orders
SELECT COUNT(*) FROM orders;

-- 2 Total revenue
SELECT SUM(total_amount) FROM orders;

-- 3 Orders per customer
SELECT customer_id, COUNT(*) FROM orders GROUP BY customer_id;

-- 4 Top 3 customers
SELECT customer_id, COUNT(*) AS total_orders
FROM orders GROUP BY customer_id
ORDER BY total_orders DESC LIMIT 3;

-- 5 Orders per city
SELECT c.city, COUNT(o.order_id)
FROM orders o JOIN customers c
ON o.customer_id=c.customer_id
GROUP BY c.city;

-- 6 Revenue per city
SELECT c.city, SUM(o.total_amount)
FROM orders o JOIN customers c
ON o.customer_id=c.customer_id
GROUP BY c.city;

-- 7 Avg delivery time per rider
SELECT rider_id, AVG(delivery_time)
FROM orders GROUP BY rider_id;

-- 8 Underperforming riders
SELECT rider_id, AVG(delivery_time) avg_time
FROM orders GROUP BY rider_id
HAVING AVG(delivery_time)>45;

-- 9 Daily orders
SELECT DATE(order_date), COUNT(*)
FROM orders GROUP BY DATE(order_date);

-- 10 Monthly orders
SELECT DATE_TRUNC('month',order_date), COUNT(*)
FROM orders GROUP BY DATE_TRUNC('month',order_date);

-- 11 Rank customers
SELECT customer_id, COUNT(*),
RANK() OVER(ORDER BY COUNT(*) DESC) rank
FROM orders GROUP BY customer_id;

-- 12 Dense rank customers
SELECT customer_id, COUNT(*),
DENSE_RANK() OVER(ORDER BY COUNT(*) DESC) rank
FROM orders GROUP BY customer_id;

-- 13 Row number customers
SELECT customer_id, COUNT(*),
ROW_NUMBER() OVER(ORDER BY COUNT(*) DESC)
FROM orders GROUP BY customer_id;

-- 14 CTE example
WITH cte AS (
 SELECT customer_id, COUNT(*) cnt
 FROM orders GROUP BY customer_id
)
SELECT * FROM cte WHERE cnt>10;

-- 15 Orders with customer name
SELECT o.order_id, c.name
FROM orders o JOIN customers c
ON o.customer_id=c.customer_id;

-- 16 Orders with rider name
SELECT o.order_id, r.rider_name
FROM orders o JOIN riders r
ON o.rider_id=r.rider_id;

-- 17 High value orders
SELECT * FROM orders WHERE total_amount>800;

-- 18 Avg order value
SELECT AVG(total_amount) FROM orders;

-- 19 Payment success count
SELECT payment_status, COUNT(*)
FROM payments GROUP BY payment_status;

-- 20 Orders with failed payment
SELECT o.order_id
FROM orders o JOIN payments p
ON o.order_id=p.order_id
WHERE p.payment_status='Failed';

-- 21 Orders per restaurant
SELECT restaurant_id, COUNT(*)
FROM orders GROUP BY restaurant_id;

-- 22 Peak hour orders
SELECT EXTRACT(HOUR FROM order_date) hr, COUNT(*)
FROM orders GROUP BY hr
ORDER BY COUNT(*) DESC;

-- 23 Index usage check
EXPLAIN ANALYZE
SELECT * FROM orders WHERE customer_id=100;

-- 24 Stored procedure call
CALL get_orders_by_customer(10);

-- 25 Rider performance summary
SELECT rider_id, COUNT(*), AVG(delivery_time)
FROM orders GROUP BY rider_id;
